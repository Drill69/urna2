"""
Views (controladores) da urna eletrônica.

Fluxo:
    index  -> tela da urna (gera uma chave única para este voto)
    buscar_candidato -> JSON usado pelo JavaScript para mostrar o candidato
    votar  -> recebe o POST do CONFIRMA e grava o voto (transação)
    confirmado -> tela "VOTO CONFIRMADO"
    finalizado -> tela "FIM"
    resultado  -> apuração dos votos
"""

import uuid

from django.conf import settings
from django.contrib import messages
from django.db import IntegrityError, transaction
from django.db.models import Count, F
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_GET, require_POST

from .forms import VotoForm
from .models import Candidato, Voto


def _cargo_padrao():
    """Cargo mostrado no topo da tela antes de o eleitor digitar o número."""
    cargo = (
        Candidato.objects.values('cargo')
        .annotate(total=Count('id'))
        .order_by('-total', 'cargo')
        .values_list('cargo', flat=True)
        .first()
    )
    return cargo or 'Vereador'


def index(request):
    """Tela principal da urna."""
    # Chave única deste voto. Ela vai escondida no formulário e só pode ser
    # usada uma vez, o que impede o registro duplicado por duplo clique.
    chave = str(uuid.uuid4())
    request.session['chave_urna'] = chave

    contexto = {
        'chave': chave,
        'digitos': settings.URNA_DIGITOS_CANDIDATO,
        'posicoes_digitos': range(settings.URNA_DIGITOS_CANDIDATO),
        'cargo': _cargo_padrao(),
    }
    return render(request, 'urna/index.html', contexto)


@require_GET
def buscar_candidato(request, numero):
    """Retorna os dados do candidato em JSON (usado pelo urna.js)."""
    if not numero.isdigit():
        return JsonResponse({'encontrado': False, 'erro': 'Número inválido.'}, status=400)

    candidato = Candidato.objects.filter(numero=numero).first()
    if candidato is None:
        return JsonResponse({'encontrado': False, 'numero': numero})

    return JsonResponse({
        'encontrado': True,
        'numero': candidato.numero,
        'nome': candidato.nome,
        'partido': candidato.partido,
        'cargo': candidato.cargo,
        'foto': candidato.foto.url if candidato.foto else None,
    })


@require_POST
def votar(request):
    """Processa o voto enviado pelo botão CONFIRMA."""
    form = VotoForm(request.POST)

    if not form.is_valid():
        for erro in form.non_field_errors():
            messages.error(request, erro)
        for campo, erros in form.errors.items():
            if campo != '__all__':
                messages.error(request, f'{campo}: {" ".join(erros)}')
        return redirect('urna:index')

    chave = form.cleaned_data['chave']
    chave_sessao = request.session.get('chave_urna')

    # A chave enviada precisa ser a mesma que foi gerada ao abrir a urna.
    if not chave_sessao or str(chave) != chave_sessao:
        if Voto.objects.filter(chave=chave).exists():
            # Voto já registrado (duplo clique / F5): apenas mostra a confirmação.
            return redirect('urna:confirmado')
        messages.error(request, 'Sessão de votação inválida. Digite novamente.')
        return redirect('urna:index')

    candidato = form.cleaned_data['candidato']
    tipo = form.cleaned_data['tipo']
    numero = form.cleaned_data['numero']

    try:
        # Tudo dentro da transação: ou grava o voto E soma no candidato,
        # ou não grava nada.
        with transaction.atomic():
            voto = Voto.objects.create(
                candidato=candidato,
                tipo=tipo,
                numero_digitado=numero if tipo != Voto.BRANCO else '',
                chave=chave,
            )
            if candidato is not None:
                # F() faz o incremento direto no banco (evita perder votos
                # quando duas pessoas votam ao mesmo tempo).
                Candidato.objects.filter(pk=candidato.pk).update(votos=F('votos') + 1)
    except IntegrityError:
        # A chave já existe no banco: outro clique chegou antes.
        return redirect('urna:confirmado')

    # A chave foi consumida; um novo voto exige abrir a urna de novo.
    del request.session['chave_urna']
    request.session['ultimo_voto'] = {'id': voto.id, 'tipo': voto.tipo}

    return redirect('urna:confirmado')


def confirmado(request):
    """Tela 'VOTO CONFIRMADO' exibida logo após o registro."""
    ultimo = request.session.get('ultimo_voto')
    if not ultimo:
        return redirect('urna:index')

    tipo_legivel = dict(Voto.TIPOS).get(ultimo['tipo'], '')
    return render(request, 'urna/confirmar.html', {
        'tipo': ultimo['tipo'],
        'tipo_legivel': tipo_legivel,
    })


def finalizado(request):
    """Tela 'FIM' - encerra a votação deste eleitor."""
    ultimo = request.session.pop('ultimo_voto', None)
    if not ultimo:
        return redirect('urna:index')
    return render(request, 'urna/finalizado.html')


def resultado(request):
    """Apuração: votos por candidato, brancos, nulos e total."""
    candidatos = list(Candidato.objects.order_by('-votos', 'nome'))

    validos = Voto.objects.filter(tipo=Voto.VALIDO).count()
    brancos = Voto.objects.filter(tipo=Voto.BRANCO).count()
    nulos = Voto.objects.filter(tipo=Voto.NULO).count()
    total = validos + brancos + nulos

    mais_votado = candidatos[0].votos if candidatos else 0
    for c in candidatos:
        # Largura da barra proporcional ao candidato mais votado.
        c.percentual_barra = round(c.votos / mais_votado * 100) if mais_votado else 0
        # Percentual em relação aos votos válidos.
        c.percentual_validos = round(c.votos / validos * 100, 1) if validos else 0

    contexto = {
        'candidatos': candidatos,
        'validos': validos,
        'brancos': brancos,
        'nulos': nulos,
        'total': total,
        'ultimos_votos': Voto.objects.select_related('candidato')[:10],
    }
    return render(request, 'urna/resultado.html', contexto)
