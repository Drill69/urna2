/* ==========================================================================
   URNA ELETRÔNICA - Simulação educacional
   urna.js: controla o teclado e a tela da urna no navegador.

   IMPORTANTE: este arquivo só melhora a experiência do usuário. O registro
   do voto é feito pelo Django (view "votar"), que valida tudo novamente.

   Estados possíveis da tela:
     inicial    -> nenhum dígito digitado
     digitando  -> número incompleto
     candidato  -> número completo e candidato encontrado
     invalido   -> número completo e candidato NÃO encontrado (voto nulo)
     branco     -> eleitor apertou BRANCO
     enviando   -> CONFIRMA apertado, formulário sendo enviado
   ========================================================================== */

(function () {
    'use strict';

    var urna = document.getElementById('urna');
    if (!urna) {
        return; // não estamos na página da urna
    }

    // ---------- Configurações vindas do template (atributos data-*) ----------
    var DIGITOS = parseInt(urna.dataset.digitos, 10) || 2;
    var URL_BUSCA = urna.dataset.urlBusca;          // ex.: /api/candidato/000/
    var FOTO_PADRAO = urna.dataset.fotoPadrao;      // imagem usada quando o candidato não tem foto

    // ---------- Elementos da tela ----------
    var el = {
        tela: document.getElementById('tela'),
        digitos: document.querySelectorAll('#digitos .digito'),
        cargo: document.getElementById('tela-cargo'),
        linhaNome: document.getElementById('linha-nome'),
        nome: document.getElementById('tela-nome'),
        linhaPartido: document.getElementById('linha-partido'),
        partido: document.getElementById('tela-partido'),
        aviso: document.getElementById('tela-aviso'),
        foto: document.getElementById('tela-foto'),
        fotoImg: document.getElementById('tela-foto-img'),
        fotoLegenda: document.getElementById('tela-foto-legenda'),
        mensagem: document.getElementById('tela-mensagem'),
        instrucoes: document.getElementById('tela-instrucoes'),
        instrucaoConfirma: document.getElementById('instrucao-confirma'),
        instrucaoCorrige: document.getElementById('instrucao-corrige'),
        led: document.getElementById('led'),
        teclas: document.querySelectorAll('.tecla'),
        form: document.getElementById('form-voto'),
        inputNumero: document.getElementById('input-numero'),
        inputTipo: document.getElementById('input-tipo')
    };

    var cargoInicial = el.cargo.textContent;

    // ---------- Estado da urna ----------
    var estado = 'inicial';
    var numero = '';
    var enviando = false;
    var requisicaoAtual = 0; // identifica a última busca, para ignorar respostas atrasadas

    // =====================================================================
    // Som (gerado pelo navegador com Web Audio, sem arquivos de áudio)
    // =====================================================================
    var audioCtx = null;

    function beep(frequencia, duracao, atraso) {
        try {
            if (!audioCtx) {
                audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            }
            var inicio = audioCtx.currentTime + (atraso || 0);
            var oscilador = audioCtx.createOscillator();
            var ganho = audioCtx.createGain();
            oscilador.type = 'square';
            oscilador.frequency.value = frequencia || 880;
            ganho.gain.setValueAtTime(0.06, inicio);
            ganho.gain.exponentialRampToValueAtTime(0.0001, inicio + (duracao || 0.06));
            oscilador.connect(ganho);
            ganho.connect(audioCtx.destination);
            oscilador.start(inicio);
            oscilador.stop(inicio + (duracao || 0.06) + 0.02);
        } catch (e) {
            // navegador sem suporte a áudio: apenas ignora
        }
    }

    function somConfirmacao() {
        beep(660, 0.09, 0);
        beep(880, 0.09, 0.11);
        beep(1320, 0.18, 0.22);
    }

    // =====================================================================
    // Funções de apresentação (atualizam a tela)
    // =====================================================================
    function definirEstado(novoEstado) {
        estado = novoEstado;
        el.tela.dataset.estado = novoEstado;
    }

    function renderizarDigitos() {
        for (var i = 0; i < el.digitos.length; i++) {
            var caixa = el.digitos[i];
            var valor = numero.charAt(i);
            caixa.textContent = valor;
            caixa.classList.toggle('digito--preenchido', valor !== '');
            caixa.classList.toggle('digito--cursor', i === numero.length && !enviando && estado !== 'branco');
        }
    }

    function mostrarMensagem(texto, erro) {
        el.mensagem.textContent = texto;
        el.mensagem.classList.remove('tela__mensagem--erro');
        if (erro) {
            // força reinício da animação de "tremer"
            void el.mensagem.offsetWidth;
            el.mensagem.classList.add('tela__mensagem--erro');
        }
    }

    function mostrarInstrucoes(textoConfirma, textoCorrige) {
        el.instrucaoConfirma.textContent = textoConfirma;
        el.instrucaoCorrige.textContent = textoCorrige;
        el.instrucoes.hidden = false;
    }

    function mostrarAviso(texto, erro) {
        el.aviso.textContent = texto;
        el.aviso.classList.toggle('tela__aviso--erro', !!erro);
        el.aviso.hidden = false;
    }

    function limparDadosCandidato() {
        el.linhaNome.hidden = true;
        el.linhaPartido.hidden = true;
        el.foto.hidden = true;
        el.aviso.hidden = true;
        el.instrucoes.hidden = true;
        el.nome.textContent = '';
        el.partido.textContent = '';
        el.fotoImg.src = '';
        el.cargo.textContent = cargoInicial;
    }

    function piscarTela() {
        el.tela.classList.remove('tela--flash');
        void el.tela.offsetWidth;
        el.tela.classList.add('tela--flash');
    }

    function telaInicial() {
        numero = '';
        definirEstado('inicial');
        limparDadosCandidato();
        renderizarDigitos();
        mostrarMensagem('Digite o número do candidato');
    }

    function mostrarCandidato(dados) {
        definirEstado('candidato');
        el.aviso.hidden = true;
        el.cargo.textContent = (dados.cargo || cargoInicial).toUpperCase();
        el.nome.textContent = dados.nome;
        el.partido.textContent = dados.partido;
        el.linhaNome.hidden = false;
        el.linhaPartido.hidden = false;
        el.fotoImg.src = dados.foto || FOTO_PADRAO;
        el.fotoImg.alt = 'Foto de ' + dados.nome;
        el.fotoLegenda.textContent = dados.cargo || '';
        el.foto.hidden = false;
        mostrarMensagem('Candidato encontrado.');
        mostrarInstrucoes('para votar', 'para alterar');
        renderizarDigitos();
        beep(1040, 0.08);
    }

    function mostrarNumeroInvalido() {
        definirEstado('invalido');
        mostrarAviso('NÚMERO INVÁLIDO', true);
        mostrarMensagem('Este voto será considerado NULO.', true);
        mostrarInstrucoes('para continuar (voto NULO)', 'para voltar');
        renderizarDigitos();
        beep(220, 0.25);
    }

    // =====================================================================
    // Comunicação com o Django (busca do candidato em JSON)
    // =====================================================================
    function buscarCandidato(numeroDigitado) {
        var idRequisicao = ++requisicaoAtual;
        mostrarMensagem('Procurando candidato...');

        fetch(URL_BUSCA.replace('000', numeroDigitado), { headers: { 'Accept': 'application/json' } })
            .then(function (resposta) { return resposta.json(); })
            .then(function (dados) {
                if (idRequisicao !== requisicaoAtual) {
                    return; // o eleitor já apertou CORRIGE; resposta antiga é ignorada
                }
                if (dados.encontrado) {
                    mostrarCandidato(dados);
                } else {
                    mostrarNumeroInvalido();
                }
            })
            .catch(function () {
                if (idRequisicao !== requisicaoAtual) {
                    return;
                }
                mostrarMensagem('Falha ao consultar o servidor. Aperte CORRIGE e tente novamente.', true);
            });
    }

    // =====================================================================
    // Ações do teclado
    // =====================================================================
    function digitar(digito) {
        if (enviando) {
            return;
        }
        if (estado === 'candidato' || estado === 'invalido' || estado === 'branco') {
            beep(220, 0.08);
            mostrarMensagem('Número completo. Aperte CONFIRMA ou CORRIGE.', true);
            return;
        }

        numero += digito;
        definirEstado('digitando');
        renderizarDigitos();
        beep(880, 0.05);

        if (numero.length === DIGITOS) {
            buscarCandidato(numero);
        } else {
            mostrarMensagem('Continue digitando...');
        }
    }

    function corrigir() {
        if (enviando) {
            return;
        }
        requisicaoAtual++; // invalida qualquer busca pendente
        telaInicial();
        piscarTela();
        beep(440, 0.08);
    }

    function votarBranco() {
        if (enviando) {
            return;
        }
        requisicaoAtual++;
        numero = '';
        limparDadosCandidato();
        definirEstado('branco');
        renderizarDigitos();
        mostrarAviso('VOTO EM BRANCO', false);
        mostrarMensagem('Você está votando em BRANCO.');
        mostrarInstrucoes('para confirmar', 'para voltar');
        beep(660, 0.08);
    }

    function confirmar() {
        if (enviando) {
            return; // impede o duplo clique
        }

        if (estado === 'inicial') {
            beep(200, 0.15);
            mostrarMensagem('Digite o número do candidato ou aperte BRANCO.', true);
            return;
        }
        if (estado === 'digitando') {
            beep(200, 0.15);
            mostrarMensagem('Número incompleto. Complete o número ou aperte CORRIGE.', true);
            return;
        }

        // Preenche o formulário escondido com o que o eleitor escolheu.
        // O Django vai conferir novamente se o número existe.
        if (estado === 'branco') {
            el.inputNumero.value = '';
            el.inputTipo.value = 'BRANCO';
        } else if (estado === 'candidato') {
            el.inputNumero.value = numero;
            el.inputTipo.value = 'VALIDO';
        } else {
            el.inputNumero.value = numero;
            el.inputTipo.value = 'NULO';
        }

        enviando = true;
        definirEstado('enviando');
        el.instrucoes.hidden = true;
        el.led.classList.add('teclado__led--ocupado');
        mostrarMensagem('Registrando voto...');
        renderizarDigitos();

        // Desabilita todas as teclas para evitar cliques repetidos.
        for (var i = 0; i < el.teclas.length; i++) {
            el.teclas[i].disabled = true;
        }

        somConfirmacao();

        // Pequeno atraso só para o som/animação serem percebidos.
        setTimeout(function () {
            el.form.submit();
        }, 450);
    }

    // =====================================================================
    // Eventos: cliques nas teclas e teclado físico
    // =====================================================================
    function animarTecla(botao) {
        if (!botao) {
            return;
        }
        botao.classList.add('tecla--pressionada');
        setTimeout(function () {
            botao.classList.remove('tecla--pressionada');
        }, 120);
    }

    function executarAcao(acao) {
        if (acao === 'corrige') {
            corrigir();
        } else if (acao === 'branco') {
            votarBranco();
        } else if (acao === 'confirma') {
            confirmar();
        }
    }

    for (var i = 0; i < el.teclas.length; i++) {
        el.teclas[i].addEventListener('click', function (evento) {
            var botao = evento.currentTarget;
            if (botao.dataset.tecla !== undefined) {
                digitar(botao.dataset.tecla);
            } else {
                executarAcao(botao.dataset.acao);
            }
        });
    }

    document.addEventListener('keydown', function (evento) {
        if (evento.repeat || evento.ctrlKey || evento.altKey || evento.metaKey) {
            return;
        }
        var tecla = evento.key;
        var botao = null;

        if (/^[0-9]$/.test(tecla)) {
            botao = document.querySelector('.tecla[data-tecla="' + tecla + '"]');
            digitar(tecla);
        } else if (tecla === 'Enter') {
            botao = document.querySelector('.tecla[data-acao="confirma"]');
            confirmar();
        } else if (tecla === 'Backspace' || tecla === 'Escape' || tecla === 'Delete') {
            botao = document.querySelector('.tecla[data-acao="corrige"]');
            corrigir();
        } else if (tecla === 'b' || tecla === 'B') {
            botao = document.querySelector('.tecla[data-acao="branco"]');
            votarBranco();
        } else {
            return;
        }

        evento.preventDefault();
        animarTecla(botao);
    });

    // Inicialização
    telaInicial();
})();
