"""
Formulários da urna.

VotoForm      -> valida, no servidor, os dados enviados pelo teclado da urna.
CandidatoForm -> validação extra usada pelo Django Admin ao cadastrar candidatos.
"""

from django import forms

from .models import Candidato, Voto


class VotoForm(forms.Form):
    """
    Dados enviados quando o eleitor aperta CONFIRMA.

    O JavaScript informa o que o eleitor "quis" fazer (tipo), mas quem decide
    o tipo real do voto é este formulário, consultando o banco de dados:

    - BRANCO -> voto em branco (não precisa de número)
    - número existente -> VALIDO, ligado ao candidato
    - número inexistente -> NULO
    """

    numero = forms.CharField(max_length=10, required=False)
    tipo = forms.ChoiceField(choices=Voto.TIPOS)
    chave = forms.UUIDField()

    def clean_numero(self):
        numero = (self.cleaned_data.get('numero') or '').strip()
        if numero and not numero.isdigit():
            raise forms.ValidationError('O número do candidato deve conter apenas dígitos.')
        return numero

    def clean(self):
        dados = super().clean()
        if self.errors:
            return dados

        numero = dados.get('numero', '')
        tipo = dados.get('tipo')

        if tipo == Voto.BRANCO:
            dados['candidato'] = None
            return dados

        if not numero:
            raise forms.ValidationError('Digite o número do candidato ou vote em BRANCO.')

        candidato = Candidato.objects.filter(numero=numero).first()
        if candidato:
            dados['tipo'] = Voto.VALIDO
            dados['candidato'] = candidato
        else:
            dados['tipo'] = Voto.NULO
            dados['candidato'] = None
        return dados


class CandidatoForm(forms.ModelForm):
    """Formulário de candidato usado pelo Django Admin."""

    class Meta:
        model = Candidato
        fields = ['numero', 'nome', 'partido', 'cargo', 'foto', 'votos']

    def clean_numero(self):
        numero = self.cleaned_data['numero'].strip()
        if not numero.isdigit():
            raise forms.ValidationError('O número deve conter apenas dígitos.')
        repetido = Candidato.objects.filter(numero=numero).exclude(pk=self.instance.pk)
        if repetido.exists():
            raise forms.ValidationError('Já existe um candidato com este número.')
        return numero

    def clean_nome(self):
        return self.cleaned_data['nome'].strip().upper()

    def clean_partido(self):
        return self.cleaned_data['partido'].strip().upper()
