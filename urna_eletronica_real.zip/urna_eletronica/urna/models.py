"""
Modelos (tabelas do banco de dados) da urna eletrônica.

Candidato -> pessoas fictícias que podem receber votos.
Voto      -> cada voto registrado (válido, branco ou nulo).
"""

import uuid

from django.core.validators import RegexValidator
from django.db import models


class Candidato(models.Model):
    """Candidato fictício cadastrado pelo administrador."""

    numero = models.CharField(
        'número',
        max_length=2,
        unique=True,  # impede dois candidatos com o mesmo número
        validators=[RegexValidator(r'^\d{2}$', 'Informe exatamente 2 dígitos (ex.: 01, 13, 33).')],
        help_text='Número que o eleitor digita na urna. Ex.: 13',
    )
    nome = models.CharField('nome', max_length=100)
    partido = models.CharField('partido', max_length=50)
    cargo = models.CharField('cargo', max_length=50, default='Vereador')
    foto = models.ImageField('foto', upload_to='candidatos/', blank=True, null=True)
    votos = models.PositiveIntegerField('votos', default=0)

    class Meta:
        verbose_name = 'candidato'
        verbose_name_plural = 'candidatos'
        ordering = ['numero']

    def __str__(self):
        return f'{self.numero} - {self.nome} ({self.partido})'


class Voto(models.Model):
    """Um voto registrado na urna. Não guarda nenhum dado do eleitor."""

    VALIDO = 'VALIDO'
    BRANCO = 'BRANCO'
    NULO = 'NULO'
    TIPOS = [
        (VALIDO, 'Válido'),
        (BRANCO, 'Branco'),
        (NULO, 'Nulo'),
    ]

    candidato = models.ForeignKey(
        Candidato,
        on_delete=models.SET_NULL,  # se o candidato for excluído, o voto continua existindo
        null=True,
        blank=True,
        related_name='registros',
        verbose_name='candidato',
    )
    tipo = models.CharField('tipo', max_length=6, choices=TIPOS)
    numero_digitado = models.CharField(
        'número digitado',
        max_length=10,
        blank=True,
        help_text='Número digitado pelo eleitor (útil para votos nulos).',
    )
    data_hora = models.DateTimeField('data e hora', auto_now_add=True)
    # Chave única gerada quando a urna é aberta. Como a coluna é UNIQUE,
    # um duplo clique no CONFIRMA nunca consegue gravar dois votos.
    chave = models.UUIDField('chave de registro', default=uuid.uuid4, unique=True, editable=False)

    class Meta:
        verbose_name = 'voto'
        verbose_name_plural = 'votos'
        ordering = ['-data_hora']

    def __str__(self):
        if self.tipo == self.VALIDO and self.candidato:
            return f'Voto válido - {self.candidato.nome}'
        return f'Voto {self.get_tipo_display().lower()}'
