"""
Testes automatizados: python manage.py test

Cobrem os fluxos principais da urna: voto válido, branco, nulo,
proteção contra duplo clique e página de resultado.
"""

from django.test import TestCase
from django.urls import reverse

from .models import Candidato, Voto


class UrnaTestCase(TestCase):
    def setUp(self):
        self.ana = Candidato.objects.create(numero='01', nome='ANA SILVA', partido='ABC')
        self.joao = Candidato.objects.create(numero='13', nome='JOÃO SANTOS', partido='XYZ')

    def abrir_urna(self):
        """Abre a tela da urna e devolve a chave gerada na sessão."""
        resposta = self.client.get(reverse('urna:index'))
        self.assertEqual(resposta.status_code, 200)
        return self.client.session['chave_urna']

    def votar(self, chave, numero='', tipo='VALIDO'):
        return self.client.post(
            reverse('urna:votar'),
            {'numero': numero, 'tipo': tipo, 'chave': chave},
        )

    def test_tela_inicial_carrega_com_estaticos(self):
        resposta = self.client.get(reverse('urna:index'))
        self.assertContains(resposta, 'urna/style.css')
        self.assertContains(resposta, 'urna/urna.js')
        self.assertContains(resposta, 'CONFIRMA')

    def test_busca_candidato_json(self):
        resposta = self.client.get(reverse('urna:buscar_candidato', args=['01']))
        self.assertEqual(resposta.json()['nome'], 'ANA SILVA')
        resposta = self.client.get(reverse('urna:buscar_candidato', args=['99']))
        self.assertFalse(resposta.json()['encontrado'])

    def test_voto_valido(self):
        chave = self.abrir_urna()
        resposta = self.votar(chave, numero='01')
        self.assertRedirects(resposta, reverse('urna:confirmado'))

        self.ana.refresh_from_db()
        self.assertEqual(self.ana.votos, 1)
        voto = Voto.objects.get()
        self.assertEqual(voto.tipo, Voto.VALIDO)
        self.assertEqual(voto.candidato, self.ana)

    def test_voto_branco(self):
        chave = self.abrir_urna()
        self.votar(chave, tipo='BRANCO')
        self.assertEqual(Voto.objects.filter(tipo=Voto.BRANCO).count(), 1)
        self.assertEqual(Candidato.objects.filter(votos__gt=0).count(), 0)

    def test_numero_inexistente_vira_nulo(self):
        chave = self.abrir_urna()
        # O JavaScript disse "VALIDO", mas o número não existe: o servidor decide.
        self.votar(chave, numero='99', tipo='VALIDO')
        voto = Voto.objects.get()
        self.assertEqual(voto.tipo, Voto.NULO)
        self.assertIsNone(voto.candidato)
        self.assertEqual(voto.numero_digitado, '99')

    def test_numero_existente_vira_valido_mesmo_se_js_disser_nulo(self):
        chave = self.abrir_urna()
        self.votar(chave, numero='13', tipo='NULO')
        self.assertEqual(Voto.objects.get().tipo, Voto.VALIDO)
        self.joao.refresh_from_db()
        self.assertEqual(self.joao.votos, 1)

    def test_duplo_clique_nao_registra_dois_votos(self):
        chave = self.abrir_urna()
        self.votar(chave, numero='01')
        resposta = self.votar(chave, numero='01')  # mesmo formulário enviado de novo
        self.assertRedirects(resposta, reverse('urna:confirmado'))
        self.assertEqual(Voto.objects.count(), 1)
        self.ana.refresh_from_db()
        self.assertEqual(self.ana.votos, 1)

    def test_chave_invalida_nao_registra(self):
        self.abrir_urna()
        resposta = self.votar('00000000-0000-0000-0000-000000000000', numero='01')
        self.assertRedirects(resposta, reverse('urna:index'))
        self.assertEqual(Voto.objects.count(), 0)

    def test_confirma_sem_numero_e_sem_branco_e_rejeitado(self):
        chave = self.abrir_urna()
        resposta = self.votar(chave, numero='', tipo='VALIDO')
        self.assertRedirects(resposta, reverse('urna:index'))
        self.assertEqual(Voto.objects.count(), 0)

    def test_votar_exige_post(self):
        resposta = self.client.get(reverse('urna:votar'))
        self.assertEqual(resposta.status_code, 405)

    def test_fluxo_confirmado_e_fim(self):
        chave = self.abrir_urna()
        self.votar(chave, numero='01')
        resposta = self.client.get(reverse('urna:confirmado'))
        self.assertContains(resposta, 'VOTO CONFIRMADO')
        resposta = self.client.get(reverse('urna:finalizado'))
        self.assertContains(resposta, 'FIM')
        # Sem voto na sessão, as telas redirecionam para a urna.
        resposta = self.client.get(reverse('urna:finalizado'))
        self.assertRedirects(resposta, reverse('urna:index'))

    def test_resultado(self):
        for numero, tipo in [('01', 'VALIDO'), ('01', 'VALIDO'), ('13', 'VALIDO'), ('', 'BRANCO'), ('77', 'NULO')]:
            chave = self.abrir_urna()
            self.votar(chave, numero=numero, tipo=tipo)

        resposta = self.client.get(reverse('urna:resultado'))
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(resposta.context['validos'], 3)
        self.assertEqual(resposta.context['brancos'], 1)
        self.assertEqual(resposta.context['nulos'], 1)
        self.assertEqual(resposta.context['total'], 5)
        self.assertEqual(resposta.context['candidatos'][0], self.ana)
        self.assertContains(resposta, 'RESULTADO DA ELEIÇÃO')

    def test_numero_duplicado_e_bloqueado(self):
        from django.db import IntegrityError
        with self.assertRaises(IntegrityError):
            Candidato.objects.create(numero='01', nome='OUTRA', partido='ZZZ')
