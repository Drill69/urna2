"""
Rotas da aplicação urna.

/                          -> tela da urna
/votar/                    -> processamento do voto (POST)
/confirmado/               -> tela VOTO CONFIRMADO
/fim/                      -> tela FIM
/resultado/                -> resultado da eleição
/api/candidato/<numero>/   -> busca do candidato em JSON (usado pelo JavaScript)
"""

from django.urls import path

from . import views

app_name = 'urna'

urlpatterns = [
    path('', views.index, name='index'),
    path('votar/', views.votar, name='votar'),
    path('confirmado/', views.confirmado, name='confirmado'),
    path('fim/', views.finalizado, name='finalizado'),
    path('resultado/', views.resultado, name='resultado'),
    path('api/candidato/<str:numero>/', views.buscar_candidato, name='buscar_candidato'),
]
