"""
Comando: python manage.py criar_candidatos_exemplo

Cadastra três candidatos FICTÍCIOS para a simulação e gera uma foto
simples (iniciais em fundo colorido) para cada um usando a biblioteca Pillow.
"""

from io import BytesIO

from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand
from PIL import Image, ImageDraw, ImageFont

from urna.models import Candidato

CANDIDATOS = [
    {'numero': '01', 'nome': 'ANA SILVA', 'partido': 'ABC', 'cargo': 'Vereador', 'cor': (31, 111, 178)},
    {'numero': '13', 'nome': 'JOÃO SANTOS', 'partido': 'XYZ', 'cargo': 'Vereador', 'cor': (46, 139, 87)},
    {'numero': '33', 'nome': 'MARIA OLIVEIRA', 'partido': 'DEF', 'cargo': 'Vereador', 'cor': (178, 76, 31)},
]


def gerar_foto(nome, cor):
    """Cria uma imagem PNG 300x360 com as iniciais do candidato."""
    largura, altura = 300, 360
    imagem = Image.new('RGB', (largura, altura), cor)
    desenho = ImageDraw.Draw(imagem)

    # Silhueta simples (cabeça + ombros) em tom mais claro
    claro = tuple(min(255, c + 60) for c in cor)
    desenho.ellipse((100, 60, 200, 160), fill=claro)
    desenho.rounded_rectangle((50, 175, 250, 320), radius=60, fill=claro)

    iniciais = ''.join(parte[0] for parte in nome.split()[:2])
    fonte = None
    for arquivo_fonte in ('arialbd.ttf', 'DejaVuSans-Bold.ttf'):  # Windows / Linux
        try:
            fonte = ImageFont.truetype(arquivo_fonte, 64)
            break
        except OSError:
            continue
    if fonte is None:
        fonte = ImageFont.load_default(size=64)
    caixa = desenho.textbbox((0, 0), iniciais, font=fonte)
    x = (largura - (caixa[2] - caixa[0])) / 2
    desenho.text((x, 225), iniciais, fill='white', font=fonte)

    buffer = BytesIO()
    imagem.save(buffer, format='PNG')
    return ContentFile(buffer.getvalue())


class Command(BaseCommand):
    help = 'Cadastra candidatos fictícios de exemplo (com fotos geradas).'

    def handle(self, *args, **options):
        for dados in CANDIDATOS:
            candidato, criado = Candidato.objects.get_or_create(
                numero=dados['numero'],
                defaults={
                    'nome': dados['nome'],
                    'partido': dados['partido'],
                    'cargo': dados['cargo'],
                },
            )
            if not candidato.foto:
                nome_arquivo = f"candidato_{dados['numero']}.png"
                candidato.foto.save(nome_arquivo, gerar_foto(dados['nome'], dados['cor']), save=True)

            situacao = 'criado' if criado else 'já existia'
            self.stdout.write(self.style.SUCCESS(f'{candidato} - {situacao}'))

        self.stdout.write(self.style.SUCCESS('Pronto! Acesse http://127.0.0.1:8000/ para votar.'))
