"""
Configuração do Django Admin (/admin/).

Permite cadastrar, editar e excluir candidatos e visualizar os votos
(tipo, candidato, data e hora) sem alterar o código.
"""

from django.contrib import admin
from django.utils.html import format_html

from .forms import CandidatoForm
from .models import Candidato, Voto


@admin.register(Candidato)
class CandidatoAdmin(admin.ModelAdmin):
    form = CandidatoForm
    list_display = ['numero', 'miniatura', 'nome', 'partido', 'cargo', 'votos']
    list_display_links = ['numero', 'nome']
    search_fields = ['numero', 'nome', 'partido']
    list_filter = ['cargo', 'partido']
    ordering = ['numero']
    readonly_fields = ['miniatura']
    fieldsets = [
        ('Identificação', {'fields': ['numero', 'nome', 'partido', 'cargo']}),
        ('Foto', {'fields': ['foto', 'miniatura']}),
        ('Apuração', {'fields': ['votos']}),
    ]

    @admin.display(description='Foto')
    def miniatura(self, obj):
        if obj.foto:
            return format_html(
                '<img src="{}" alt="{}" style="height:48px;border-radius:6px;">',
                obj.foto.url, obj.nome,
            )
        return '-'


@admin.register(Voto)
class VotoAdmin(admin.ModelAdmin):
    list_display = ['id', 'tipo', 'candidato', 'numero_digitado', 'data_hora']
    list_filter = ['tipo', 'data_hora', 'candidato']
    date_hierarchy = 'data_hora'
    ordering = ['-data_hora']
    readonly_fields = ['candidato', 'tipo', 'numero_digitado', 'data_hora', 'chave']

    # Votos são criados apenas pela urna: o admin só visualiza (e pode excluir
    # para zerar uma simulação).
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


admin.site.site_header = 'Urna Eletrônica - Administração'
admin.site.site_title = 'Urna Eletrônica'
admin.site.index_title = 'Painel da simulação'
