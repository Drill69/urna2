# EXPLICAÇÃO DO PROJETO — arquivo por arquivo

Este documento explica, em linguagem simples, como cada parte da
**URNA ELETRÔNICA REAL (simulação educacional)** funciona. Ele foi pensado
para apoiar a apresentação do projeto em sala.

Sumário

1. Visão geral do fluxo
2. `settings.py`
3. `urls.py` (projeto e app)
4. `models.py`
5. `forms.py`
6. `views.py`
7. `admin.py`
8. `criar_candidatos_exemplo.py`
9. Templates (`base`, `index`, `confirmar`, `finalizado`, `resultado`)
10. `style.css`
11. `urna.js`
12. `tests.py`
13. Como a proteção contra duplo clique funciona (resumo)

---

## 1. Visão geral do fluxo

```
Navegador (HTML + CSS + JS)                Servidor (Django + SQLite)
---------------------------                ---------------------------
GET /              ───────────────────►    index()  gera uma CHAVE única,
                   ◄───────────────────    guarda na sessão e devolve index.html

eleitor digita 1, 3
GET /api/candidato/13/ ────────────────►   buscar_candidato() consulta o banco
                   ◄───────────────────    JSON {encontrado, nome, partido, foto...}
JS mostra o candidato na tela

eleitor aperta CONFIRMA
POST /votar/ (numero, tipo, chave, csrf) ► votar(): VotoForm valida no servidor,
                                           confere a chave, grava Voto e soma
                                           +1 no candidato (transação)
                   ◄───────────────────    redirect /confirmado/
GET /confirmado/   ───────────────────►    "VOTO CONFIRMADO" (3 s)
GET /fim/          ───────────────────►    "FIM"
```

A regra de ouro do projeto: **o JavaScript só melhora a experiência; quem
decide se o voto é válido, branco ou nulo é o Django**, consultando o banco.

---

## 2. `urna_eletronica/settings.py`

Arquivo de configuração do projeto. Pontos importantes:

```python
INSTALLED_APPS = [
    'django.contrib.admin',      # painel administrativo
    'django.contrib.auth',       # usuários/login do admin
    'django.contrib.sessions',   # sessão (usada na chave anti-duplo-clique)
    'django.contrib.messages',   # mensagens de erro na tela
    'django.contrib.staticfiles',# CSS/JS
    'urna',                      # nossa aplicação
]

MIDDLEWARE = [ ..., 'django.middleware.csrf.CsrfViewMiddleware', ... ]  # proteção CSRF

DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3',
                         'NAME': BASE_DIR / 'db.sqlite3'}}

LANGUAGE_CODE = 'pt-br'
TIME_ZONE = 'America/Sao_Paulo'

STATIC_URL = 'static/'                 # CSS e JS  -> urna/static/urna/
MEDIA_URL = 'media/'                   # fotos enviadas pelo admin
MEDIA_ROOT = BASE_DIR / 'media'

URNA_DIGITOS_CANDIDATO = 2             # quantidade de dígitos do número
```

- `LANGUAGE_CODE = 'pt-br'` deixa o Django Admin em português.
- `USE_TZ = True` + `TIME_ZONE` fazem a data/hora do voto aparecer no horário
  de Brasília.
- `URNA_DIGITOS_CANDIDATO` é uma configuração própria; a view e o template a
  usam para desenhar as caixinhas dos dígitos.

---

## 3. Rotas — `urls.py`

### `urna_eletronica/urls.py` (projeto)

```python
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('urna.urls')),
]
if settings.DEBUG:   # em desenvolvimento, o Django serve as fotos da pasta media/
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

### `urna/urls.py` (app)

| URL | View | Função |
|-----|------|--------|
| `/` | `index` | tela da urna |
| `/votar/` | `votar` | recebe o POST do CONFIRMA |
| `/confirmado/` | `confirmado` | "VOTO CONFIRMADO" |
| `/fim/` | `finalizado` | "FIM" |
| `/resultado/` | `resultado` | apuração |
| `/api/candidato/<numero>/` | `buscar_candidato` | JSON usado pelo JavaScript |

`app_name = 'urna'` permite usar `{% url 'urna:votar' %}` nos templates, sem
escrever endereços fixos (evita links quebrados).

---

## 4. `urna/models.py` — banco de dados

### Candidato

```python
class Candidato(models.Model):
    numero  = CharField(max_length=2, unique=True,
                        validators=[RegexValidator(r'^\d{2}$', ...)])
    nome    = CharField(max_length=100)
    partido = CharField(max_length=50)
    cargo   = CharField(max_length=50, default='Vereador')
    foto    = ImageField(upload_to='candidatos/', blank=True, null=True)
    votos   = PositiveIntegerField(default=0)
```

- `numero` é texto (não inteiro) para preservar o zero à esquerda (`01`).
- `unique=True` cria uma restrição **no banco**: nunca haverá dois candidatos
  com o mesmo número, mesmo que alguém tente burlar o formulário.
- `foto` é opcional; quando não existe, o template usa `img/sem-foto.svg`.

### Voto

```python
class Voto(models.Model):
    VALIDO, BRANCO, NULO = 'VALIDO', 'BRANCO', 'NULO'

    candidato       = ForeignKey(Candidato, on_delete=SET_NULL, null=True, blank=True)
    tipo            = CharField(max_length=6, choices=TIPOS)
    numero_digitado = CharField(max_length=10, blank=True)
    data_hora       = DateTimeField(auto_now_add=True)
    chave           = UUIDField(default=uuid.uuid4, unique=True, editable=False)
```

- `candidato` fica vazio (`NULL`) em votos brancos e nulos.
- `on_delete=SET_NULL`: se um candidato for excluído no admin, o histórico de
  votos não é apagado — só perde a ligação.
- `auto_now_add=True` grava a data/hora automaticamente.
- `chave` é a peça central da proteção contra duplo clique (ver seção 13).
- Nenhum dado do eleitor é armazenado.

---

## 5. `urna/forms.py` — validação no servidor

### VotoForm

Recebe `numero`, `tipo` e `chave` do formulário escondido e **decide sozinho**
o tipo final do voto:

```python
def clean(self):
    ...
    if tipo == Voto.BRANCO:
        dados['candidato'] = None          # branco não tem candidato
        return dados
    if not numero:
        raise ValidationError('Digite o número do candidato ou vote em BRANCO.')

    candidato = Candidato.objects.filter(numero=numero).first()
    if candidato:
        dados['tipo'] = Voto.VALIDO        # existe -> VÁLIDO
        dados['candidato'] = candidato
    else:
        dados['tipo'] = Voto.NULO          # não existe -> NULO
        dados['candidato'] = None
    return dados
```

Isso garante a regra "não confiar só no JavaScript": se alguém alterar o HTML
e enviar `tipo=NULO` para um número que existe, o Django corrige para VÁLIDO
(há um teste automatizado exatamente para isso).

### CandidatoForm

Usado pelo Django Admin. Além do `unique` do banco, dá uma mensagem amigável
quando o número já existe e converte nome e partido para MAIÚSCULAS.

---

## 6. `urna/views.py` — lógica de cada página

### `index(request)`

```python
chave = str(uuid.uuid4())
request.session['chave_urna'] = chave
```

Gera uma chave única, guarda na **sessão** e envia para o template (campo
oculto). Também passa `posicoes_digitos` para desenhar as caixinhas.

### `buscar_candidato(request, numero)` — `@require_GET`

Devolve JSON. Se o número não é só dígitos → HTTP 400. Se não existe →
`{"encontrado": false}`. Se existe → nome, partido, cargo e URL da foto.

### `votar(request)` — `@require_POST`

1. `VotoForm(request.POST)` valida e define o tipo do voto.
2. Confere se a `chave` enviada é a mesma da sessão. Se não for, mas já existir
   um voto com essa chave, apenas redireciona para "VOTO CONFIRMADO" (foi um
   duplo clique ou F5) — **não grava de novo**.
3. Grava dentro de uma transação:

```python
with transaction.atomic():
    voto = Voto.objects.create(candidato=candidato, tipo=tipo,
                               numero_digitado=..., chave=chave)
    if candidato is not None:
        Candidato.objects.filter(pk=candidato.pk).update(votos=F('votos') + 1)
```

   - `transaction.atomic()`: ou grava o voto **e** soma no candidato, ou não
     faz nada (nunca fica pela metade).
   - `F('votos') + 1`: o incremento é feito pelo banco, evitando perder votos
     se dois eleitores confirmarem ao mesmo tempo.
4. `except IntegrityError`: a chave já existia (outro clique chegou antes) →
   redireciona sem gravar.
5. Apaga a chave da sessão (foi consumida) e guarda `ultimo_voto` para a
   tela de confirmação.

### `confirmado` e `finalizado`

Só funcionam se existir `ultimo_voto` na sessão; caso contrário voltam para a
urna. `finalizado` remove esse dado (`session.pop`), encerrando o eleitor.

### `resultado(request)`

Conta `VALIDO`, `BRANCO`, `NULO` e o total; ordena os candidatos por votos e
calcula dois percentuais por candidato:

- `percentual_barra` → largura da barra (relativa ao mais votado);
- `percentual_validos` → % dos votos válidos.

---

## 7. `urna/admin.py` — painel administrativo

```python
@admin.register(Candidato)
class CandidatoAdmin(admin.ModelAdmin):
    form = CandidatoForm
    list_display = ('numero', 'miniatura', 'nome', 'partido', 'cargo', 'votos')
    list_filter = ('cargo', 'partido')
    search_fields = ('numero', 'nome', 'partido')

@admin.register(Voto)
class VotoAdmin(admin.ModelAdmin):
    list_display = ('id', 'tipo', 'candidato', 'numero_digitado', 'data_hora')
    list_filter = ('tipo', 'data_hora', 'candidato')
    date_hierarchy = 'data_hora'
    def has_add_permission(...):    return False   # voto só nasce pela urna
    def has_change_permission(...): return False   # somente leitura
```

- `miniatura` mostra a foto pequena na lista.
- Votos não podem ser criados nem editados pelo admin (só visualizados e, se
  necessário, excluídos para zerar a simulação).
- Os títulos do admin foram alterados para "Urna Eletrônica - Administração".

---

## 8. `urna/management/commands/criar_candidatos_exemplo.py`

Comando `python manage.py criar_candidatos_exemplo`. Usa `get_or_create`
(pode rodar várias vezes sem duplicar) e gera, com a biblioteca Pillow, uma
imagem ilustrativa com as iniciais de cada candidato fictício. Nenhuma foto de
pessoa real é usada.

---

## 9. Templates (`urna/templates/urna/`)

### `base.html`

Esqueleto de todas as páginas: `<head>` com `{% load static %}` e o
`style.css`, cabeçalho com navegação (Urna / Resultado / Admin), área
`{% block conteudo %}` e rodapé com o aviso de simulação.

### `index.html` — a urna

No topo exibe as mensagens de erro do Django (`{% for mensagem in messages %}`),
usadas quando a view `votar` recusa um envio. Depois vêm as duas metades:

- **Tela (esquerda)**: cabeçalho "SEU VOTO PARA — VEREADOR", caixinhas dos
  dígitos (`{% for posicao in posicoes_digitos %}`), linhas Nome/Partido, área
  da foto com legenda do cargo, aviso grande (NÚMERO INVÁLIDO / VOTO EM
  BRANCO), mensagem do sistema e instruções (CONFIRMA/CORRIGE). Os elementos
  que ainda não devem aparecer usam o atributo `hidden`.
- **Teclado (direita)**: botões `0-9` com `data-digito`, e `BRANCO`, `CORRIGE`,
  `CONFIRMA` com `data-acao`.

No fim há um **formulário escondido**:

```django
<form id="form-voto" method="post" action="{% url 'urna:votar' %}">
    {% csrf_token %}
    <input type="hidden" name="numero" id="input-numero">
    <input type="hidden" name="tipo"   id="input-tipo">
    <input type="hidden" name="chave"  value="{{ chave }}">
</form>
```

É esse formulário que o JavaScript preenche e envia quando o eleitor aperta
CONFIRMA. O `{% csrf_token %}` é obrigatório para o POST ser aceito.

Configurações passadas ao JS via `data-*` no `<section id="urna">`:
`data-digitos`, `data-url-busca` e `data-foto-padrao`.

### `confirmar.html`

Mostra o ícone de check, **VOTO CONFIRMADO**, uma frase com o tipo do voto e
um contador regressivo de 3 s (pequeno script na própria página) que
redireciona para `/fim/`. Há também o botão "Continuar agora".

### `finalizado.html`

Mostra **FIM**, mensagem de encerramento e os botões "Novo eleitor" (volta
para `/`, gerando uma nova chave) e "Ver resultado".

### `resultado.html`

Lista ordenada (`<ol>`) com posição, foto, número, nome, partido, barra
(`style="width: {{ c.percentual_barra }}%"`) e votos; depois os quatro cartões
de totais (válidos, brancos, nulos, total) e um `<details>` com os últimos
votos registrados.

---

## 10. `urna/static/urna/style.css`

CSS próprio (sem Bootstrap), organizado em blocos:

1. **Variáveis** (`:root`) com as cores: fundo escuro, tela clara, verde do
   CONFIRMA, laranja do CORRIGE, branco do BRANCO, vermelho de erro.
2. **Layout geral**: `body`, cabeçalho, rodapé.
3. **Corpo da urna** (`.urna`): `display: grid` com duas colunas
   (tela ~2/3 e teclado ~1/3), bordas arredondadas, sombras que dão o aspecto
   de equipamento físico.
4. **Tela** (`.tela`): fundo claro, fonte monoespaçada, caixinhas dos dígitos,
   área da foto, aviso em destaque, área de mensagens.
5. **Teclado** (`.teclado`): botões grandes com relevo (`box-shadow` inferior),
   efeito de pressionar (`.tecla--pressionada`), LED de status.
6. **Botões de ação**: `.tecla--branco`, `.tecla--corrige`, `.tecla--confirma`
   (o CONFIRMA é o maior e ocupa a linha inteira).
7. **Animações**: `@keyframes` para o candidato aparecer, piscar a tela ao
   corrigir e o check da confirmação.
8. **Resultado**: ranking, barras com transição de largura, cartões de totais.
9. **Responsividade**: `@media (max-width: 960px)` coloca o teclado abaixo da
   tela (tablet); `@media (max-width: 600px)` reduz tamanhos para celular.
10. `.oculto, [hidden] { display: none !important; }` garante que elementos
    escondidos não apareçam.

---

## 11. `urna/static/urna/urna.js`

Todo o código fica dentro de uma função anônima `(function () { ... })();`
para não poluir o escopo global. Estrutura:

**Configuração e elementos** — lê `data-digitos`, `data-url-busca`,
`data-foto-padrao` e guarda referências dos elementos da tela no objeto `el`.

**Estado** — variáveis `estado` (`inicial`, `digitando`, `candidato`,
`invalido`, `branco`, `enviando`), `numero` (dígitos digitados), `enviando`
(trava de envio) e `requisicaoAtual` (ignora respostas atrasadas da API).

**Funções de tela** — `renderizarDigitos`, `mostrarMensagem`,
`mostrarInstrucoes`, `mostrarAviso`, `limparDadosCandidato`, `piscarTela`,
`telaInicial`, `mostrarCandidato(dados)`, `mostrarNumeroInvalido()`.

**Comunicação com o Django**

```js
fetch(URL_BUSCA.replace('000', numeroDigitado))
    .then(r => r.json())
    .then(dados => dados.encontrado ? mostrarCandidato(dados) : mostrarNumeroInvalido());
```

**Ações**

- `digitar(d)`: acrescenta o dígito; ao completar 2 dígitos chama a API.
  Se o número já está completo, avisa para CONFIRMAR ou CORRIGIR.
- `corrigir()`: zera tudo, volta para a tela inicial e pisca a tela.
- `votarBranco()`: limpa o número e mostra "VOTO EM BRANCO".
- `confirmar()`: se `estado` for `inicial` ou `digitando`, mostra erro e não
  envia. Caso contrário, preenche os campos ocultos (`numero`, `tipo`), marca
  `enviando = true`, **desabilita todas as teclas** e faz `form.submit()`
  após 450 ms (tempo do som/animação). Um segundo clique é ignorado pela trava.

**Eventos** — clique em cada `.tecla` (lê `data-digito`/`data-acao`) e
`keydown` no documento: números, `Enter` (CONFIRMA), `Backspace`/`Escape`/
`Delete` (CORRIGE), `B` (BRANCO).

**Som** — `beep()` e `somConfirmacao()` usam a Web Audio API para tocar tons
curtos (se o navegador não suportar, simplesmente não toca).

---

## 12. `urna/tests.py`

13 testes com `django.test.TestCase` (banco temporário). Principais:

| Teste | O que garante |
|-------|---------------|
| tela inicial + estáticos | `/`, CSS e JS respondem 200 |
| API | JSON correto para número existente e inexistente |
| voto válido | cria `Voto VALIDO` e `candidato.votos` vira 1 |
| voto branco | cria `Voto BRANCO`, nenhum candidato incrementado |
| número inexistente | vira `NULO` |
| JS "mentindo" | envia `tipo=NULO` com número existente → Django grava VÁLIDO |
| duplo clique | dois POST com a mesma chave → apenas 1 voto |
| chave inválida | não grava e volta para a urna com erro |
| CONFIRMA sem número | não grava |
| GET em `/votar/` | HTTP 405 |
| confirmado/fim | telas certas e sessão encerrada |
| resultado | totais e percentuais corretos |
| número duplicado | `CandidatoForm` recusa |

Rodar: `python manage.py test`.

---

## 13. Resumo: proteção contra duplo clique (3 camadas)

1. **JavaScript**: variável `enviando` + `disabled` em todas as teclas após o
   primeiro CONFIRMA.
2. **Sessão**: a view `index` gera uma chave UUID e a guarda na sessão; a
   view `votar` só aceita essa chave e a apaga depois de usar.
3. **Banco**: `Voto.chave` é `unique`. Se dois pedidos chegarem ao mesmo tempo,
   o segundo gera `IntegrityError` e é redirecionado para "VOTO CONFIRMADO"
   sem gravar nada.

Assim, mesmo sem JavaScript ou com um F5 na hora errada, cada abertura da urna
gera **no máximo um voto**.
