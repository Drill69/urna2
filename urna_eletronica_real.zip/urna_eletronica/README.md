# URNA ELETRÔNICA REAL — Simulação Educacional

Projeto acadêmico desenvolvido para a disciplina de Programação Web do curso
Técnico em Informática. É uma **simulação de urna eletrônica** feita com
**Python + Django + SQLite + HTML + CSS + JavaScript**.

> **Aviso:** este sistema é apenas uma simulação para fins de estudo.
> Não tem nenhuma ligação com eleições reais, não usa dados reais e todos
> os candidatos são fictícios.

---

## 1. Objetivo do projeto

Demonstrar, em um único projeto, os principais conteúdos de programação web:

- **Back-end** com Django (models, views, forms, urls, admin, transações);
- **Banco de dados** relacional com SQLite (migrações, chaves estrangeiras,
  `unique`, `F()` para incremento atômico);
- **Front-end** com HTML5, CSS3 (sem Bootstrap) e JavaScript puro
  (`fetch`, eventos, manipulação do DOM, teclado físico e virtual);
- **Boas práticas**: CSRF, validação no servidor, prevenção de duplo clique,
  testes automatizados.

O visual é inspirado em um equipamento eletrônico (fundo escuro, tela clara,
teclado numérico, botões grandes), mas é uma interpretação educacional — não
copia a interface de nenhum equipamento oficial.

---

## 2. Tecnologias utilizadas

| Tecnologia | Uso |
|------------|-----|
| Python 3.10+ | Linguagem principal |
| Django 5.2 | Framework web (MVT) |
| SQLite | Banco de dados (arquivo `db.sqlite3`) |
| Pillow | Necessário para o campo de foto (`ImageField`) |
| HTML5 / CSS3 | Estrutura e visual da urna (CSS próprio, responsivo) |
| JavaScript (ES5, sem frameworks) | Teclado, busca do candidato, animações, bloqueio de duplo clique |

---

## 3. Estrutura de pastas

```
urna_eletronica/
│
├── manage.py                  # utilitário de linha de comando do Django
├── requirements.txt           # dependências (Django e Pillow)
├── README.md                  # este arquivo
├── EXPLICACAO.md              # explicação detalhada de cada arquivo
├── .gitignore
│
├── urna_eletronica/           # configuração do projeto
│   ├── __init__.py
│   ├── settings.py            # banco, apps, idioma, static/media
│   ├── urls.py                # rotas principais (/admin/ + app urna)
│   ├── asgi.py
│   └── wsgi.py
│
└── urna/                      # aplicação da urna
    ├── migrations/
    │   ├── __init__.py
    │   └── 0001_initial.py    # cria as tabelas Candidato e Voto
    ├── management/commands/
    │   └── criar_candidatos_exemplo.py   # cadastra 3 candidatos fictícios
    ├── templates/urna/
    │   ├── base.html          # layout comum (cabeçalho, rodapé, CSS)
    │   ├── index.html         # tela principal da urna
    │   ├── confirmar.html     # "VOTO CONFIRMADO"
    │   ├── finalizado.html    # "FIM"
    │   └── resultado.html     # apuração com barras
    ├── static/urna/
    │   ├── style.css          # todo o visual da urna
    │   ├── urna.js            # comportamento do teclado e do fluxo
    │   └── img/sem-foto.svg   # imagem usada quando o candidato não tem foto
    ├── admin.py               # configuração do Django Admin
    ├── apps.py
    ├── forms.py               # VotoForm (validação do voto) e CandidatoForm
    ├── models.py              # Candidato e Voto
    ├── tests.py               # 13 testes automatizados
    ├── urls.py                # rotas da urna
    └── views.py               # lógica de cada página
```

Quando o projeto roda pela primeira vez são criados automaticamente:
`db.sqlite3` (banco) e a pasta `media/` (fotos enviadas pelo admin).

---

## 4. Como instalar

Pré-requisito: **Python 3.10 ou superior** instalado
(no Windows, marque "Add Python to PATH" na instalação).

Abra a pasta do projeto no VS Code, abra o terminal (`Ctrl + '`) e execute:

### Windows (PowerShell ou CMD)

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

### Linux / macOS

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

> Se o PowerShell bloquear a ativação do venv, execute uma vez:
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

O que cada comando faz:

| Comando | Função |
|---------|--------|
| `python -m venv venv` | cria um ambiente virtual isolado |
| `venv\Scripts\activate` | ativa o ambiente virtual |
| `pip install -r requirements.txt` | instala Django e Pillow |
| `python manage.py migrate` | cria as tabelas no SQLite |
| `python manage.py createsuperuser` | cria o usuário do painel `/admin/` |
| `python manage.py runserver` | inicia o servidor em `http://127.0.0.1:8000/` |

---

## 5. Como executar

Com o ambiente virtual ativado:

```bash
python manage.py runserver
```

Depois acesse no navegador:

| Endereço | Página |
|----------|--------|
| http://127.0.0.1:8000/ | **Urna** (tela principal) |
| http://127.0.0.1:8000/resultado/ | **Resultado** da votação |
| http://127.0.0.1:8000/admin/ | **Painel administrativo** |

Para parar o servidor, pressione `Ctrl + C` no terminal.

---

## 6. Como criar o superusuário

```bash
python manage.py createsuperuser
```

Informe um nome de usuário, e-mail (opcional) e senha. Esse usuário é usado
para entrar em `http://127.0.0.1:8000/admin/`.

---

## 7. Como cadastrar candidatos

### Opção A — pelo Django Admin (recomendado)

1. Acesse `http://127.0.0.1:8000/admin/` e faça login;
2. Clique em **Candidatos → Adicionar candidato**;
3. Preencha **Número** (2 dígitos, ex.: `01`), **Nome**, **Partido**,
   **Cargo** e, se quiser, uma **Foto**;
4. Salve.

O sistema impede números duplicados e converte nome/partido para maiúsculas,
como aparece na tela da urna. Não é necessário alterar nenhum código.

### Opção B — candidatos fictícios de exemplo

Para preencher o banco rapidamente com os três candidatos usados nos testes:

```bash
python manage.py criar_candidatos_exemplo
```

Isso cadastra (com fotos ilustrativas geradas automaticamente):

```
01 — ANA SILVA        Partido: ABC   Cargo: Vereador
13 — JOÃO SANTOS      Partido: XYZ   Cargo: Vereador
33 — MARIA OLIVEIRA   Partido: DEF   Cargo: Vereador
```

---

## 8. Como usar a urna

1. Acesse `http://127.0.0.1:8000/`;
2. Digite o número do candidato no teclado da tela (ou no teclado físico);
3. A urna busca o candidato e mostra número, nome, partido, cargo e foto;
4. Pressione **CONFIRMA** para votar ou **CORRIGE** para recomeçar;
5. Aparece **VOTO CONFIRMADO** e, em seguida, **FIM**;
6. Clique em **Novo eleitor** para liberar a urna para o próximo voto.

Outros casos:

- **BRANCO** → mostra "VOTO EM BRANCO"; CONFIRMA registra um voto `BRANCO`.
- **Número inexistente** (ex.: `99`) → mostra "NÚMERO INVÁLIDO"; CONFIRMA
  registra um voto `NULO`; CORRIGE volta ao início.
- **CONFIRMA sem digitar nada** → a urna avisa e não envia nada.

Atalhos do teclado físico: números `0-9`, `Enter` = CONFIRMA,
`Backspace`/`Esc` = CORRIGE, `B` = BRANCO.

---

## 9. Como acessar os resultados

Acesse `http://127.0.0.1:8000/resultado/`. A página mostra:

- ranking dos candidatos com foto, número, nome, partido, votos e barra
  proporcional;
- totais de **VOTOS VÁLIDOS**, **VOTOS BRANCOS**, **VOTOS NULOS** e
  **TOTAL DE VOTOS**;
- lista dos últimos votos registrados (tipo, candidato e data/hora).

Para **zerar a simulação**, entre no admin, vá em **Votos**, selecione todos
e use a ação "Remover votos selecionados"; depois edite cada candidato e
zere o campo **Votos** (ou apague e recrie os candidatos).

---

## 10. Segurança e validação implementadas

- **CSRF**: todo POST passa pelo `CsrfViewMiddleware` e o formulário envia o
  token `{% csrf_token %}`.
- **Validação no servidor**: o `VotoForm` decide o tipo do voto consultando o
  banco — mesmo que o JavaScript envie um tipo errado, o Django corrige.
- **Números únicos**: `Candidato.numero` tem `unique=True` + validação no
  formulário do admin.
- **Duplo clique**: cada tela da urna recebe uma **chave única** (UUID) guardada
  na sessão e gravada no campo `Voto.chave` (`unique`). Um segundo envio com a
  mesma chave é ignorado. O JavaScript também desabilita os botões após
  CONFIRMA.
- **Transação**: criação do `Voto` e incremento de `Candidato.votos`
  (`F('votos') + 1`) acontecem dentro de `transaction.atomic()`.
- **Sem dados pessoais**: o voto guarda apenas tipo, candidato, número digitado
  e data/hora.

---

## 11. Testes automatizados

```bash
python manage.py test
```

São 13 testes que cobrem: carregamento da tela e dos arquivos estáticos, API
de busca do candidato, voto válido, branco e nulo, duplo clique, chave inválida,
CONFIRMA sem número, bloqueio de GET em `/votar/`, telas de confirmação/fim,
cálculo do resultado e número de candidato duplicado.

---

## 12. Observações

- O projeto está configurado para **desenvolvimento local** (`DEBUG = True`).
  Não use essas configurações em um servidor público.
- Não há arquivos `.pyc` ou pastas `__pycache__` no projeto entregue; o Python
  pode gerá-los ao rodar, e eles já estão no `.gitignore`.
- Para explicações detalhadas de cada arquivo, consulte **EXPLICACAO.md**.
