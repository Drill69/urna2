"""
Configurações do projeto URNA ELETRÔNICA (simulação educacional).

Projeto acadêmico do curso Técnico em Informática. Não possui nenhuma
relação com eleições reais.
"""

from pathlib import Path

# Pasta raiz do projeto (onde fica o manage.py)
BASE_DIR = Path(__file__).resolve().parent.parent


# ---------------------------------------------------------------------------
# Segurança (configuração de desenvolvimento)
# ---------------------------------------------------------------------------

# AVISO: em um sistema real esta chave deve ficar em segredo (variável de ambiente).
SECRET_KEY = 'django-insecure-urna-eletronica-educacional-troque-esta-chave'

# DEBUG=True mostra páginas de erro detalhadas. Nunca use em produção.
DEBUG = True

ALLOWED_HOSTS = ['localhost', '127.0.0.1']


# ---------------------------------------------------------------------------
# Aplicações instaladas
# ---------------------------------------------------------------------------

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    # Aplicação da urna
    'urna',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    # Proteção CSRF: todo formulário POST precisa do {% csrf_token %}
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'urna_eletronica.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        # APP_DIRS=True faz o Django procurar templates em urna/templates/
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'urna_eletronica.wsgi.application'


# ---------------------------------------------------------------------------
# Banco de dados (SQLite - arquivo db.sqlite3 na raiz do projeto)
# ---------------------------------------------------------------------------

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


# ---------------------------------------------------------------------------
# Validação de senhas (usada pelo createsuperuser e pelo admin)
# ---------------------------------------------------------------------------

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]


# ---------------------------------------------------------------------------
# Idioma e fuso horário
# ---------------------------------------------------------------------------

LANGUAGE_CODE = 'pt-br'

TIME_ZONE = 'America/Sao_Paulo'

USE_I18N = True

# Datas são salvas em UTC no banco e exibidas no fuso acima.
USE_TZ = True


# ---------------------------------------------------------------------------
# Arquivos estáticos (CSS, JavaScript, imagens do sistema)
# ---------------------------------------------------------------------------

STATIC_URL = 'static/'


# ---------------------------------------------------------------------------
# Arquivos de mídia (fotos dos candidatos enviadas pelo admin)
# ---------------------------------------------------------------------------

MEDIA_URL = 'media/'
MEDIA_ROOT = BASE_DIR / 'media'


# ---------------------------------------------------------------------------
# Configurações da urna
# ---------------------------------------------------------------------------

# Quantidade de dígitos do número do candidato (ex.: 2 -> "01", "13", "33")
URNA_DIGITOS_CANDIDATO = 2

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
