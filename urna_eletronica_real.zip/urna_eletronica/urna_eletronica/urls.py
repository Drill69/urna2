"""
Rotas principais do projeto.

/admin/  -> painel administrativo do Django
/        -> rotas da aplicação "urna" (urna/urls.py)
"""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('urna.urls')),
]

# Em desenvolvimento (DEBUG=True) o próprio Django serve as fotos dos candidatos.
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
